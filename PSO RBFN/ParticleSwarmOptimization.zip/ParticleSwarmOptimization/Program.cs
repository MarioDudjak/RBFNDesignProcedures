﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace ParticleSwarmOptimization
{
    class Program
    {
        static void Main(string[] args)
        {
			Random rnd = new Random(1);

            DataSet Iris = new DataSet(3, new string[] { "Iris-setosa", "Iris-versicolor", "Iris-virginica" });
            Iris.ImportData("Iris.txt");
			//DataSet Iris = new DataSet(6, new string[] { "1", "2", "3", "4", "5", "6" });
			//Iris.ImportData("glass.txt"); //Nein
			//DataSet Iris = new DataSet(3, new string[] { "1", "2", "3" });
			//Iris.ImportData("thyroid.txt");
			//DataSet Iris = new DataSet(3, new string[] { "1", "2", "3" });
			//Iris.ImportData("seeds.txt");
			//DataSet Iris = new DataSet(3, new string[] { "1", "2", "3" });
			//Iris.ImportData("wine.txt");
			//DataSet Iris = new DataSet(2, new string[] { "1", "2" });
			//Iris.ImportData("parkinsons.txt");
			//DataSet Iris = new DataSet(4, new string[] { "1", "2", "3", "4" });
			//Iris.ImportData("statlog.txt"); //Nein
			//DataSet Iris = new DataSet(3, new string[] { "1", "2", "3" });
			//Iris.ImportData("cmc.txt"); //Nein
			//DataSet Iris = new DataSet(6, new string[] { "1", "2", "3", "4", "5", "6" });
			//Iris.ImportData("vowel.txt");
            //DataSet Iris = new DataSet(2, new string[] { "0", "1" });
            //Iris.ImportData("banknote.txt");
			//DataSet Iris = new DataSet(2, new string[] { "1", "2" });
			//Iris.ImportData("ionosphere.txt");
			//DataSet Iris = new DataSet(2, new string[] { "0", "1" });
			//Iris.ImportData("thoracic.txt");
			//DataSet Iris = new DataSet(2, new string[] { "1", "2" });
			//Iris.ImportData("pima.txt");
			//DataSet Iris = new DataSet(2, new string[] { "1", "2" });
			//Iris.ImportData("liver.txt");
			//DataSet Iris = new DataSet(2, new string[] { "1", "2" });
			//Iris.ImportData("ILPD.txt");


			DataSet[] tve = Iris.splitDataset(rnd, new double[] { 80, 20 });

			PSO pso = new PSO(tve[0]);
			pso.Run(20, 0.9, 2, 2, 5000, 2, 20);

			double[][] c = pso.getCenters();
			double[] w = pso.getWidths();
			RBFNN net = new RBFNN(c, w, tve[0]);
			net.PInvWeights();

			double mcr = net.misclassificationRate(tve[1]);
			Console.WriteLine(mcr + "\t" + w.Length);
        }
    }
}
